##########################
# LOKI (c)2021 HB7A Soft.#
##########################

#L'uso di LOKI prevede la conoscenza dell'ambiente di addestramento / attacco e difesa.

INSTALLAZIONE:
versione portabile

OS:
Windows 10

Driver richiesti ( installare prima di avviare LOKI ):
i Driver Digispark sono contenuti nella cartella: .\micronucleus\install.exe

Avvio:
.\Loki.exe

ATTENZIONE:
Usare la modalità "TEST" per controllare se il driver Digispark funziona correttamente. 