#############################
# LOKI (c)2021 007cyber.com #
#############################

RubberDucky hex generator for tiny85 Mcu.

TYPE:
Portable (PE)

install first:
Digispark Driver are available in .\micronucleus\install.exe folder.

cmdline (no args):
.\Loki.exe

